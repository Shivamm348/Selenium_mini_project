package mini_project;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excel {

public static void setSheet(String[] results) throws IOException {
		FileOutputStream file=new FileOutputStream(".\\EXCELFILE\\mini.xlsx");
		XSSFWorkbook workbook=new XSSFWorkbook();
		XSSFSheet sheet=workbook.createSheet("SearchResult");
		
//For Search Result Sheet
		//row 1
		XSSFRow row1=sheet.createRow(0);
		row1.createCell(0).setCellValue("All result"); 
		row1.createCell(1).setCellValue(results[0]);
		
		//row 2
		XSSFRow row2=sheet.createRow(1);
		row2.createCell(0).setCellValue("News Result");
		row2.createCell(1).setCellValue(results[1]);
		
		//row 3
		XSSFRow row3=sheet.createRow(2);
		row3.createCell(0).setCellValue("Videos Result");
		row3.createCell(1).setCellValue(results[2]);

		
		//write or create file
		workbook.write(file);
		file.close();
		workbook.close();
		
	}



	public static void setColumn(ArrayList<String> results)  throws IOException {
		FileInputStream file=new FileInputStream(".\\EXCELFILE\\mini.xlsx");
		XSSFWorkbook workbook=new XSSFWorkbook(file);
		XSSFSheet sheet1=workbook.createSheet("links");
		
		sheet1.createRow(0).createCell(0).setCellValue("Link Name:");
		
		for(int i = 0; i<results.size(); i++) {
			XSSFRow row = sheet1.createRow(i+1);
			XSSFCell cell = row.createCell(0);
			cell.setCellValue(results.get(i));
		}
		file.close();
		FileOutputStream file2 = new FileOutputStream(".\\EXCELFILE\\mini.xlsx");
		workbook.write(file2);
		file2.close();
		workbook.close();
		
		
		
	
	}
	
	public static void setnextColumn(ArrayList<String> results)  throws IOException {
		FileInputStream file=new FileInputStream(".\\EXCELFILE\\mini.xlsx");
		XSSFWorkbook workbook=new XSSFWorkbook(file);
		XSSFSheet sheet2=workbook.createSheet("Options");
		
		sheet2.createRow(0).createCell(0).setCellValue("Option Name:");
		
		for(int i = 0; i<results.size(); i++) {
			XSSFRow row = sheet2.createRow(i+1);
			XSSFCell cell = row.createCell(0);
			cell.setCellValue(results.get(i));
		}
		file.close();
		FileOutputStream file3 = new FileOutputStream(".\\EXCELFILE\\mini.xlsx");
		workbook.write(file3);
		file3.close();
		workbook.close();
		
		
		
	
	}
   public static String gettext() throws IOException {
	   FileInputStream file=new FileInputStream(".\\EXCELFILE\\GetText.xlsx");
	   XSSFWorkbook workbook=new XSSFWorkbook(file);
	   XSSFSheet sheet=workbook.getSheet("Sheet1");
	   
	   String term = sheet.getRow(0).getCell(0).toString();
	   file.close();
	   workbook.close();
	   
	   return term;
	   
	   
   }
}
