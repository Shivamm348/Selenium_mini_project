package mini_project;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class cognizant {

	public static void main(String[] args) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver=DriverSetup.getWebdriver();
		driver.get("https://www.google.com/");
		driver.manage().window().maximize();
		
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(3));
		
		//finding Number of links:
		List<WebElement>links=driver.findElements(By.xpath("//a"));
		 System.out.println();
		System.out.println("Total Number of links are:"+links.size());
		 System.out.println();
		 ArrayList <String> lnk=new ArrayList<String>(); 
 		
		for(WebElement link:links) {
			if(link.getText().length()==0) {
				System.out.println("Link Name Not Available");
				continue;
			}
			System.out.println(link.getText());	
			
			lnk.add(link.getText());
		
			
		}
	
		//filling cognizant
		
		WebElement fill=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//textarea[@class='gLFyf']")));
		String data=fill.getText();
		String searchTerm = Excel.gettext();
		fill.sendKeys(searchTerm);
		
		//finding options
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@class='G43f7e']/li")));
		List<WebElement> options=driver.findElements(By.xpath("//ul[@class='G43f7e']/li"));
		
 		System.out.println();
		System.out.println("Total no. of Options:"+options.size());
		 System.out.println();
		ArrayList<String> cogopt=new ArrayList<String>();
		for(WebElement Opt:options) {
			System.out.println(Opt.getText());	
            cogopt.add(Opt.getText());
            

		}
		
		//Taking Screen Shot-
		WebElement options1=driver.findElement(By.xpath("//div[@class='mkHrUc']"));
    	File src=options1.getScreenshotAs(OutputType.FILE);
        File trg=new File(".\\Screenshot\\option1.png");
        FileUtils.copyFile(src,trg);
        
        //click on search button
        driver.findElement(By.xpath("//input[@class='gNO89b']")).click();
        
        //click on ALL
        driver.findElement(By.xpath("//span[text()='All']"));

        // Print the number of search results
        System.out.println();
        System.out.println("Total no. of Search Result for All : " + driver.findElement(By.id("result-stats")).getText());
        String allNum = driver.findElement(By.id("result-stats")).getText();
        WebElement allFilter = driver.findElement(By.xpath("//div[@class='hdtb-mitem hdtb-msel']"));
        allFilter.click();
        //screenshot of fullpage of search result
         TakesScreenshot ta=(TakesScreenshot)driver;
         File src1=ta.getScreenshotAs(OutputType.FILE);
         File trg1=new File(".\\Screenshot\\All.png");
         FileUtils.copyFile(src1,trg1);
         
         //click on News
         driver.findElement(By.xpath("//a[text()='News']")).click();
         WebElement news=driver.findElement(By.xpath("//div[@id='result-stats']"));
         String newsNum = news.getText();
         System.out.println("Total no. of Search Result for News : "+ news.getText() );
         
         //Full page Screen shot for news page
         TakesScreenshot tn=(TakesScreenshot)driver;
         File src2=tn.getScreenshotAs(OutputType.FILE);
         File trg2=new File(".\\Screenshot\\News.png");
         FileUtils.copyFile(src2,trg2);
         
      
         //click on images
         
         WebElement elementToClick= wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()='Images']")));
         elementToClick.click();
         //taking screenshot
         TakesScreenshot ti=(TakesScreenshot)driver;
         File src3=ti.getScreenshotAs(OutputType.FILE);
         File trg3=new File(".//Screenshot//images.png");
         FileUtils.copyFile(src3, trg3);
         
         //click on videos
         driver.findElement(By.xpath("//a[text()='Videos']")).click();
         
         WebElement videos=driver.findElement(By.xpath("//span[text()='Videos']"));
         WebElement vr=driver.findElement(By.xpath("//div[@id='result-stats']"));
         String videoNum = vr.getText();
         System.out.println("Total no. of Search Result for Videos : "+ vr.getText());
         System.out.println();
         //Taking full page screen shot of videos
         TakesScreenshot tv=(TakesScreenshot)driver;
         File src4=tv.getScreenshotAs(OutputType.FILE);
         File trg4=new File(".//Screenshot//video.png");
         FileUtils.copyFile(src4, trg4);
         
         //closing the driver
         driver.quit();
         
         String[] results = {allNum,newsNum,videoNum};
         
         Excel.setSheet(results);
         Excel.setColumn(lnk);
         Excel.setnextColumn(cogopt);
    
         //Excel.setColumn(cogopt);
         
        
        
	}

}
