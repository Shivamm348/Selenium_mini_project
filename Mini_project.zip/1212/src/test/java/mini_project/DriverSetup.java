package mini_project;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chromium.ChromiumDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.util.*;

public class DriverSetup {
	
	private static WebDriver driver;
  public static WebDriver getWebdriver() {
	  Scanner sc=new Scanner(System.in);
	  System.out.print("Enter Browser Name(chrome/edge/firfox):");
	  String browser=sc.next();
//	  String Chrome,FireFox,Edge;
	  
	  if(browser.equalsIgnoreCase("Chrome")) {
		   driver=new ChromeDriver();
		   
		  
	  }else if(browser.equalsIgnoreCase("Firefox")) {
		  driver=new FirefoxDriver();
	  }
	  else if(browser.equalsIgnoreCase("Edge")) {
		  driver=new EdgeDriver();
	  }
	  else{
		  System.out.println("Invalid Output");
	  }
	  String baseurl="https://www.google.com";
	  driver.get(baseurl);
	
	   return driver;
   }

}
